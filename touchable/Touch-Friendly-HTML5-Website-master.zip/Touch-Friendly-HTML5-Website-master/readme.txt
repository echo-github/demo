This is an HTML5 experiement. Specifically, I wanted to see exactly how close I could come to making a website ‘feel’ like a native app.  The site is targeted for use on iPad/iOS, but should work in all modern browsers.  

An in depth article about the source can be found here: http://blogs.claritycon.com/design/2011/07/25/building-a-touch-friendly-html5-site/


This sample website demonstrates how to do the following:

Avoiding the use of jQuery for optimized perf on mobile devices
Adding touch capabilites to screen elements
Using hardware accelerated css animations
Detecting browser capabilities with Modernizr
An inertial scroller to workaround the lack of native scrolling in a fixed layout on iOS